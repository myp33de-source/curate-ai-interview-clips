#!/usr/bin/env python3
"""Maintain a small JSON ledger for proposed, approved, and processed videos."""

from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path


VALID_STATUSES = ("proposed", "approved", "processed", "rejected")


def load(path: Path) -> dict:
    if not path.exists():
        return {"videos": {}}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or not isinstance(payload.get("videos", {}), dict):
        raise ValueError("state file must contain a videos object")
    payload.setdefault("videos", {})
    return payload


def save(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--state", type=Path, default=Path("ai_interview_runs/state.json"))
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init")
    list_parser = sub.add_parser("list")
    list_parser.add_argument("--status", choices=VALID_STATUSES)
    mark = sub.add_parser("mark")
    mark.add_argument("video_id")
    mark.add_argument("status", choices=VALID_STATUSES)
    mark.add_argument("--title", default="")
    mark.add_argument("--url", default="")
    args = parser.parse_args()

    payload = load(args.state)
    if args.command == "init":
        save(args.state, payload)
        print(args.state)
        return 0
    if args.command == "list":
        for video_id, item in sorted(payload["videos"].items()):
            if args.status and item.get("status") != args.status:
                continue
            print(f"{video_id}\t{item.get('status', '')}\t{item.get('title', '')}")
        return 0

    item = payload["videos"].get(args.video_id, {})
    item.update(
        {
            "status": args.status,
            "title": args.title or item.get("title", ""),
            "url": args.url or item.get("url", ""),
            "updated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        }
    )
    payload["videos"][args.video_id] = item
    save(args.state, payload)
    print(f"{args.video_id}\t{args.status}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
