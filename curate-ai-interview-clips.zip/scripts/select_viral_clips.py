#!/usr/bin/env python3
"""Select high-spread-potential clip windows from candidate transcripts."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from download_and_clip import load_transcript_api_cues, parse_vtt, safe_slug  # noqa: E402


DEFAULT_INPUT = ROOT / "outputs" / "daily_candidates_2026-06-26.json"
DEFAULT_OUTPUT = ROOT / "viral_clip_specs_2026-06-26.json"

BOOST_TERMS = {
    "fortune 500": 16,
    "killing": 16,
    "replace": 12,
    "replaces": 12,
    "anthropic": 12,
    "ai anxiety": 12,
    "anxiety": 10,
    "agents": 10,
    "agent": 8,
    "voice agent": 14,
    "coding": 10,
    "solved": 10,
    "engineering pyramid": 16,
    "organizational structure": 12,
    "bottleneck": 10,
    "verification": 9,
    "millions": 12,
    "agi": 10,
    "economy": 8,
    "enterprise": 8,
    "ceo": 5,
    "founder": 5,
    "hire": 8,
    "hires": 8,
}

AD_TERMS = [
    "sponsor",
    "sponsored",
    "brought to you by",
    "work os",
    "workos",
    "use code",
    "promo code",
    "sign up",
    "subscribe",
    "newsletter",
    "link in the description",
]


def load_candidates(path: Path) -> List[Dict[str, object]]:
    return json.loads(path.read_text(encoding="utf-8"))["candidates"]


def find_video_dir(video_id: str, title: str, drafts_dir: Path) -> Path:
    matches = sorted(drafts_dir.glob(f"{video_id}_*"))
    if matches:
        return matches[-1]
    return drafts_dir / f"{video_id}_{safe_slug(title)}"


def load_cues(video_dir: Path) -> List[Dict[str, object]]:
    api = video_dir / "transcript_api.json"
    cues = load_transcript_api_cues(api)
    if cues:
        return cues
    vtts = sorted(video_dir.glob("*.vtt"))
    for vtt in vtts:
        cues = parse_vtt(vtt)
        if cues:
            return cues
    return []


def score_text(text: str) -> int:
    lower = text.lower()
    if any(term in lower for term in AD_TERMS):
        return -1000
    score = 0
    for term, weight in BOOST_TERMS.items():
        if term in lower:
            score += weight
    score += min(lower.count("?"), 2) * 4
    score += min(len(re.findall(r"\b\d+[\d,.]*\b", lower)), 3) * 3
    if 350 <= len(text) <= 1200:
        score += 8
    if ">>" in text:
        score += 3
    return score


def window_candidates(cues: List[Dict[str, object]], min_len: int, max_len: int) -> List[Dict[str, object]]:
    windows = []
    cues = compact_cues(cues)[:1500]
    texts = [str(c["text"]) for c in cues]
    for i, cue in enumerate(cues):
        start = float(cue["start"])
        for j in range(i, min(len(cues), i + 80)):
            end = float(cues[j]["end"])
            duration = end - start
            if duration < min_len:
                continue
            if duration > max_len:
                break
            text = " ".join(texts[i : j + 1])
            score = score_text(text)
            if score > 0:
                windows.append(
                    {
                        "start": start,
                        "end": end,
                        "duration": duration,
                        "score": score,
                        "text": text,
                    }
                )
    windows.sort(key=lambda x: (x["score"], x["duration"]), reverse=True)
    return windows


def compact_cues(cues: List[Dict[str, object]]) -> List[Dict[str, object]]:
    compacted = []
    bucket = None
    for cue in cues:
        text = str(cue["text"]).strip()
        if not text:
            continue
        if bucket is None:
            bucket = {"start": float(cue["start"]), "end": float(cue["end"]), "text": text}
            continue
        can_merge = float(cue["end"]) - float(bucket["start"]) <= 6.0
        if can_merge:
            bucket["end"] = float(cue["end"])
            if text not in str(bucket["text"]):
                bucket["text"] = str(bucket["text"]) + " " + text
        else:
            compacted.append(bucket)
            bucket = {"start": float(cue["start"]), "end": float(cue["end"]), "text": text}
    if bucket is not None:
        compacted.append(bucket)
    return compacted


def overlaps(a: Dict[str, object], b: Dict[str, object]) -> bool:
    return max(float(a["start"]), float(b["start"])) < min(float(a["end"]), float(b["end"]))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--drafts-dir", type=Path, default=ROOT / "clip_drafts")
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--per-video", type=int, default=2)
    parser.add_argument("--min-len", type=int, default=35)
    parser.add_argument("--max-len", type=int, default=118)
    args = parser.parse_args()

    selected = []
    per_video_counts: Dict[str, int] = {}
    all_windows = []
    for candidate in load_candidates(args.input):
        video_id = str(candidate["url"]).split("v=")[-1]
        title = str(candidate["title"])
        video_dir = find_video_dir(video_id, title, args.drafts_dir)
        cues = load_cues(video_dir)
        if not cues:
            continue
        for window in window_candidates(cues, args.min_len, args.max_len)[:8]:
            all_windows.append({**candidate, **window, "video_id": video_id, "video_dir": str(video_dir)})

    all_windows.sort(key=lambda x: x["score"], reverse=True)
    for window in all_windows:
        vid = str(window["video_id"])
        if per_video_counts.get(vid, 0) >= args.per_video:
            continue
        if any(vid == str(s["video_id"]) and overlaps(window, s) for s in selected):
            continue
        selected.append(window)
        per_video_counts[vid] = per_video_counts.get(vid, 0) + 1
        if len(selected) >= args.limit:
            break

    specs = []
    for idx, item in enumerate(selected, start=1):
        specs.append(
            {
                "rank": idx,
                "video_id": item["video_id"],
                "channel": item["channel"],
                "title": item["title"],
                "url": item["url"],
                "start": round(float(item["start"]), 2),
                "end": round(float(item["end"]), 2),
                "duration": round(float(item["duration"]), 2),
                "score": item["score"],
                "text": item["text"],
            }
        )
    args.output.write_text(json.dumps(specs, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[done] Wrote {args.output}")
    for spec in specs:
        print(f"#{spec['rank']} {spec['score']} {spec['video_id']} {spec['start']}-{spec['end']} {spec['title']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
