#!/usr/bin/env python3
"""
Fetch recent videos from a small YouTube source list and flag AI interview candidates.

This MVP intentionally uses public channel RSS feeds instead of the YouTube Data API:
- no API key needed
- good enough for a curated 5-channel watchlist
- easy to swap for the official API later
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import html
import json
import re
import socket
import subprocess
import sys
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple


ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCES = ROOT / "sources.csv"
DEFAULT_OUTPUT_DIR = ROOT / "outputs"
USER_AGENT = "ai-interview-radar/0.1"

GLOBAL_AI_TERMS = [
    "ai",
    "a.i.",
    "artificial intelligence",
    "agi",
    "agent",
    "agents",
    "llm",
    "openai",
    "anthropic",
    "deepmind",
    "gemini",
    "chatgpt",
    "claude",
    "model",
    "models",
    "automation",
    "robotics",
]

INTERVIEW_TERMS = [
    "interview",
    "conversation",
    "podcast",
    "fireside",
    "talk",
    "founder",
    "ceo",
    "cto",
    "researcher",
    "scientist",
]

EXCLUDE_TERMS = [
    "trailer",
    "teaser",
    "shorts",
    "#shorts",
    "live now",
    "premiere",
]


def fetch_text(url: str, timeout: int = 8) -> str:
    try:
        result = subprocess.run(
            ["curl", "-L", "-s", "--max-time", str(timeout), "-A", USER_AGENT, url],
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout + 2,
        )
    except (subprocess.TimeoutExpired, OSError) as exc:
        raise urllib.error.URLError(str(exc)) from exc

    if result.returncode == 0 and result.stdout:
        return result.stdout

    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        charset = resp.headers.get_content_charset() or "utf-8"
        return raw.decode(charset, errors="replace")


def resolve_channel_id(channel_url: str) -> Optional[str]:
    """Resolve a YouTube @handle/channel URL to a channel ID."""
    channel_match = re.search(r"/channel/(UC[a-zA-Z0-9_-]+)", channel_url)
    if channel_match:
        return channel_match.group(1)

    try:
        page = fetch_text(channel_url)
    except (urllib.error.URLError, TimeoutError) as exc:
        print(f"[warn] Failed to open {channel_url}: {exc}", file=sys.stderr)
        return None

    patterns = [
        r'"channelId"\s*:\s*"(UC[a-zA-Z0-9_-]+)"',
        r'"externalId"\s*:\s*"(UC[a-zA-Z0-9_-]+)"',
        r'<meta itemprop="channelId" content="(UC[a-zA-Z0-9_-]+)">',
        r'https://www\.youtube\.com/channel/(UC[a-zA-Z0-9_-]+)',
    ]
    for pattern in patterns:
        match = re.search(pattern, page)
        if match:
            return match.group(1)
    return None


def parse_iso_datetime(value: str) -> Optional[dt.datetime]:
    if not value:
        return None
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def fetch_rss_videos(channel_id: str) -> List[Dict[str, str]]:
    rss_url = f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}"
    xml_text = fetch_text(rss_url)
    root = ET.fromstring(xml_text)
    ns = {
        "atom": "http://www.w3.org/2005/Atom",
        "yt": "http://www.youtube.com/xml/schemas/2015",
        "media": "http://search.yahoo.com/mrss/",
    }

    videos: List[Dict[str, str]] = []
    for entry in root.findall("atom:entry", ns):
        video_id = text_or_empty(entry.find("yt:videoId", ns))
        title = text_or_empty(entry.find("atom:title", ns))
        published = text_or_empty(entry.find("atom:published", ns))
        updated = text_or_empty(entry.find("atom:updated", ns))
        author = entry.find("atom:author/atom:name", ns)
        group = entry.find("media:group", ns)
        description = ""
        thumbnail = ""
        if group is not None:
            description = text_or_empty(group.find("media:description", ns))
            thumb = group.find("media:thumbnail", ns)
            if thumb is not None:
                thumbnail = thumb.attrib.get("url", "")

        videos.append(
            {
                "video_id": video_id,
                "title": title,
                "url": f"https://www.youtube.com/watch?v={video_id}",
                "published": published,
                "updated": updated,
                "channel_title": text_or_empty(author),
                "description": description,
                "thumbnail": thumbnail,
            }
        )
    return videos


def fetch_ytdlp_videos(channel_url: str, limit: int) -> List[Dict[str, str]]:
    """Fallback to yt-dlp when YouTube returns a blocked or malformed RSS feed."""
    videos_url = channel_url.rstrip("/") + "/videos"
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "yt_dlp",
            "--flat-playlist",
            "--playlist-end",
            str(limit),
            "--dump-single-json",
            videos_url,
        ],
        check=False,
        capture_output=True,
        text=True,
        timeout=45,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "yt-dlp channel fetch failed")
    payload = json.loads(result.stdout)
    videos: List[Dict[str, str]] = []
    for entry in payload.get("entries") or []:
        if not entry:
            continue
        video_id = str(entry.get("id") or "")
        if not video_id:
            continue
        upload_date = str(entry.get("upload_date") or "")
        published = ""
        if len(upload_date) == 8 and upload_date.isdigit():
            published = f"{upload_date[:4]}-{upload_date[4:6]}-{upload_date[6:]}T00:00:00+00:00"
        videos.append(
            {
                "video_id": video_id,
                "title": str(entry.get("title") or ""),
                "url": f"https://www.youtube.com/watch?v={video_id}",
                "published": published,
                "updated": published,
                "channel_title": str(entry.get("channel") or entry.get("uploader") or ""),
                "description": str(entry.get("description") or ""),
                "thumbnail": str(entry.get("thumbnail") or ""),
            }
        )
    return videos


def text_or_empty(node: Optional[ET.Element]) -> str:
    return "" if node is None or node.text is None else node.text.strip()


def split_terms(value: str) -> List[str]:
    return [term.strip() for term in value.split(";") if term.strip()]


def term_hits(text: str, terms: Iterable[str]) -> List[str]:
    lower = text.lower()
    hits = []
    for term in terms:
        needle = term.lower()
        if not needle:
            continue
        if is_term_match(lower, needle):
            hits.append(term)
    return hits


def is_term_match(text: str, term: str) -> bool:
    if len(term) <= 3 and re.fullmatch(r"[a-z0-9.]+", term):
        compact = re.escape(term).replace(r"\.", r"\.?")
        return re.search(rf"(?<![a-z0-9]){compact}(?![a-z0-9])", text) is not None
    if re.fullmatch(r"[a-z0-9 ]+", term):
        return re.search(rf"(?<![a-z0-9]){re.escape(term)}(?![a-z0-9])", text) is not None
    return term in text


def score_video(video: Dict[str, str], source: Dict[str, str]) -> Tuple[int, List[str], List[str]]:
    title = html.unescape(video.get("title", ""))
    description = html.unescape(video.get("description", ""))
    haystack = f"{title}\n{description}"

    source_terms = split_terms(source.get("keywords", ""))
    title_ai_hits = unique_preserve_order(term_hits(title, GLOBAL_AI_TERMS))
    description_ai_hits = [
        term for term in unique_preserve_order(term_hits(description, GLOBAL_AI_TERMS))
        if term.lower() not in {hit.lower() for hit in title_ai_hits}
    ]
    ai_hits = unique_preserve_order(title_ai_hits + description_ai_hits)
    source_hits = [
        term for term in unique_preserve_order(term_hits(haystack, source_terms))
        if term.lower() not in {hit.lower() for hit in ai_hits}
    ]
    interview_hits = unique_preserve_order(term_hits(haystack, INTERVIEW_TERMS))
    exclude_hits = unique_preserve_order(term_hits(haystack, EXCLUDE_TERMS))

    score = 0
    score += min(len(title_ai_hits), 6) * 3
    score += min(len(description_ai_hits), 4)
    score += min(len(interview_hits), 4) * 2
    score += min(len(source_hits), 2)
    if source.get("priority") == "S":
        score += 1
    if not ai_hits:
        score -= 6
    if exclude_hits:
        score -= 5

    reasons = []
    if title_ai_hits:
        reasons.append("Title AI keywords: " + ", ".join(title_ai_hits[:6]))
    if description_ai_hits:
        reasons.append("Description AI keywords: " + ", ".join(description_ai_hits[:4]))
    if source_hits:
        reasons.append("Source keywords: " + ", ".join(source_hits[:4]))
    if interview_hits:
        reasons.append("Interview signals: " + ", ".join(interview_hits[:4]))
    if source.get("priority") == "S":
        reasons.append("S-priority source")
    if exclude_hits:
        reasons.append("Excluded/low-value signals: " + ", ".join(exclude_hits))

    return score, reasons, exclude_hits


def unique_preserve_order(items: Iterable[str]) -> List[str]:
    seen = set()
    result = []
    for item in items:
        key = item.lower()
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def load_sources(path: Path) -> List[Dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def within_days(video: Dict[str, str], days: int, now: dt.datetime) -> bool:
    published = parse_iso_datetime(video.get("published", ""))
    if published is None:
        return True
    if published.tzinfo is None:
        published = published.replace(tzinfo=dt.timezone.utc)
    return published >= now - dt.timedelta(days=days)


def build_candidate(
    source: Dict[str, str],
    video: Dict[str, str],
    channel_id: str,
    score: int,
    reasons: List[str],
) -> Dict[str, object]:
    directions = split_terms(source.get("clip_directions", ""))
    return {
        "channel": source.get("channel", ""),
        "priority": source.get("priority", ""),
        "channel_id": channel_id,
        "title": video.get("title", ""),
        "url": video.get("url", ""),
        "published": video.get("published", ""),
        "score": score,
        "recommendation": recommendation_label(score),
        "clip_directions": directions,
        "reasons": reasons,
        "thumbnail": video.get("thumbnail", ""),
    }


def recommendation_label(score: int) -> str:
    if score >= 18:
        return "High"
    if score >= 10:
        return "Maybe"
    return "Watchlist"


def write_markdown(candidates: List[Dict[str, object]], output_path: Path, generated_at: str) -> None:
    lines = [
        "# AI Interview Candidates",
        "",
        f"Generated at: {generated_at}",
        "",
        "| 推荐 | 分数 | 频道 | 视频标题 | 发布时间 | 推荐切片方向 | 命中原因 | 链接 |",
        "|---|---:|---|---|---|---|---|---|",
    ]

    if not candidates:
        lines.append("| - | - | - | No candidates found | - | - | - | - |")
    else:
        for item in candidates:
            title = escape_md(str(item["title"]))
            directions = "<br>".join(escape_md(x) for x in item.get("clip_directions", []))
            reasons = "<br>".join(escape_md(x) for x in item.get("reasons", []))
            lines.append(
                "| {recommendation} | {score} | {channel} | {title} | {published} | {directions} | {reasons} | [Open]({url}) |".format(
                    recommendation=item["recommendation"],
                    score=item["score"],
                    channel=escape_md(str(item["channel"])),
                    title=title,
                    published=escape_md(str(item["published"])[:10]),
                    directions=directions,
                    reasons=reasons,
                    url=item["url"],
                )
            )

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def escape_md(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ").strip()


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch latest YouTube videos from AI interview sources.")
    parser.add_argument("--sources", type=Path, default=DEFAULT_SOURCES, help="Path to sources.csv")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR, help="Directory for reports")
    parser.add_argument("--days", type=int, default=14, help="Only include videos published in the last N days")
    parser.add_argument("--min-score", type=int, default=8, help="Minimum score to include in the report")
    parser.add_argument("--max-per-channel", type=int, default=8, help="Max recent RSS items to inspect per channel")
    args = parser.parse_args()

    now = dt.datetime.now(dt.timezone.utc)
    generated_at = now.astimezone().isoformat(timespec="seconds")
    sources = load_sources(args.sources)
    candidates: List[Dict[str, object]] = []
    errors: List[str] = []

    for source in sources:
        channel_name = source.get("channel", "")
        channel_url = source.get("url", "")
        channel_id = source.get("channel_id", "").strip()
        if channel_id:
            print(f"[info] Using saved channel ID for {channel_name}: {channel_id}", flush=True)
        else:
            print(f"[info] Resolving {channel_name}...", flush=True)
            channel_id = resolve_channel_id(channel_url)
        if not channel_id:
            errors.append(f"{channel_name}: could not resolve channel ID")
            continue

        print(f"[info] Fetching RSS for {channel_name} ({channel_id})...", flush=True)
        try:
            videos = fetch_rss_videos(channel_id)[: args.max_per_channel]
        except (urllib.error.URLError, ET.ParseError, TimeoutError, socket.timeout, subprocess.TimeoutExpired) as exc:
            print(f"[warn] RSS failed for {channel_name}; trying yt-dlp: {exc}", file=sys.stderr)
            try:
                videos = fetch_ytdlp_videos(channel_url, args.max_per_channel)
            except (RuntimeError, json.JSONDecodeError, subprocess.TimeoutExpired) as fallback_exc:
                errors.append(f"{channel_name}: RSS failed ({exc}); yt-dlp failed ({fallback_exc})")
                continue

        for video in videos:
            if not within_days(video, args.days, now):
                continue
            score, reasons, exclude_hits = score_video(video, source)
            if score >= args.min_score and not exclude_hits:
                candidates.append(build_candidate(source, video, channel_id, score, reasons))

    candidates.sort(key=lambda item: (int(item["score"]), str(item["published"])), reverse=True)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    date_slug = now.astimezone().strftime("%Y-%m-%d")
    json_path = args.output_dir / f"daily_candidates_{date_slug}.json"
    md_path = args.output_dir / f"daily_candidates_{date_slug}.md"

    payload = {
        "generated_at": generated_at,
        "sources": len(sources),
        "candidate_count": len(candidates),
        "candidates": candidates,
        "errors": errors,
    }
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    write_markdown(candidates, md_path, generated_at)

    print(f"[done] Wrote {md_path}")
    print(f"[done] Wrote {json_path}")
    if errors:
        print("[warn] Some sources failed:", file=sys.stderr)
        for error in errors:
            print(f"  - {error}", file=sys.stderr)
    return 0 if candidates or not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
