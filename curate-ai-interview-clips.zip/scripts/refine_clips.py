#!/usr/bin/env python3
"""Create manually refined horizontal clips from curated timestamp specs."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from download_and_clip import download_clip, get_ffmpeg_path, safe_slug  # noqa: E402


DEFAULT_SPECS = ROOT / "refined_clip_specs.json"
DEFAULT_OUTPUT_DIR = ROOT / "refined_clips"


def main() -> int:
    parser = argparse.ArgumentParser(description="Cut refined clips from manually selected timestamps.")
    parser.add_argument("--specs", type=Path, default=DEFAULT_SPECS)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    args = parser.parse_args()

    ffmpeg = get_ffmpeg_path()
    specs = json.loads(args.specs.read_text(encoding="utf-8"))
    summary = []

    for spec in specs:
        video_dir = args.output_dir / f"{spec['video_id']}_{safe_slug(spec['title'])}"
        video_dir.mkdir(parents=True, exist_ok=True)
        clip = {
            "start": float(spec["start"]),
            "end": float(spec["end"]),
            "duration": float(spec["end"]) - float(spec["start"]),
            "score": 0,
            "text": "",
        }
        print(f"[info] Cutting {spec['video_id']} {clip['duration']:.1f}s", flush=True)
        output = download_clip(spec, clip, video_dir, 1, ffmpeg)
        summary.append({**spec, "file": str(output) if output else None})

    summary_path = args.output_dir / "refined_summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[done] Wrote {summary_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
