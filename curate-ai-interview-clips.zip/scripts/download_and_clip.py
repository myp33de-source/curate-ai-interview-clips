#!/usr/bin/env python3
"""
Download subtitles for candidate YouTube videos and create rough clip drafts.

This is an internal editor workflow:
- Pull English subtitles / auto captions when available.
- Pick rough 60-90s highlight windows with a transparent heuristic.
- Download only those sections as review drafts.

Review copyright, context, and factual accuracy before any publishing.
"""

from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple


ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / "vendor"
if VENDOR.exists():
    sys.path.insert(0, str(VENDOR))

try:
    import imageio_ffmpeg
except ImportError:  # pragma: no cover
    imageio_ffmpeg = None

try:
    from youtube_transcript_api import YouTubeTranscriptApi
except ImportError:  # pragma: no cover
    YouTubeTranscriptApi = None


DEFAULT_INPUT = ROOT / "outputs" / f"daily_candidates_{dt.datetime.now().strftime('%Y-%m-%d')}.json"
DEFAULT_OUTPUT_DIR = ROOT / "clip_drafts"

KEYWORDS = [
    "ai",
    "agent",
    "agents",
    "coding",
    "engineer",
    "engineering",
    "developer",
    "software",
    "claude",
    "anthropic",
    "deepmind",
    "model",
    "models",
    "startup",
    "founder",
    "product",
    "workflow",
    "automation",
    "future",
    "replace",
    "solved",
    "work",
]

SIGNAL_PHRASES = [
    "the important thing",
    "what happens",
    "the reason",
    "the problem",
    "the way",
    "i think",
    "we believe",
    "you should",
    "what changes",
    "it means",
]


def safe_slug(value: str, max_len: int = 70) -> str:
    value = value.lower()
    value = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "-", value)
    value = re.sub(r"-+", "-", value).strip("-")
    return value[:max_len].strip("-") or "video"


def load_candidates(path: Path, limit: int) -> List[Dict[str, object]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    candidates = payload.get("candidates", [])
    return candidates[:limit] if limit else candidates


def get_ffmpeg_path() -> Optional[str]:
    if imageio_ffmpeg is not None:
        try:
            return imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            pass
    return shutil.which("ffmpeg")


def run_yt_dlp(args: List[str], timeout: int = 300) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(VENDOR) + os.pathsep + env.get("PYTHONPATH", "")
    cmd = [
        sys.executable,
        "-m",
        "yt_dlp",
        "--extractor-args",
        "youtube:player_client=ios,android",
    ] + args
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env)


def download_subtitles(candidate: Dict[str, object], video_dir: Path) -> Optional[Path]:
    video_dir.mkdir(parents=True, exist_ok=True)
    url = str(candidate["url"])
    video_id = video_id_from_url(url)
    output_tpl = str(video_dir / f"{video_id}.%(ext)s")

    result = run_yt_dlp(
        [
            "--skip-download",
            "--write-subs",
            "--write-auto-subs",
            "--sub-langs",
            "en.*,en",
            "--sub-format",
            "vtt",
            "--no-playlist",
            "-o",
            output_tpl,
            url,
        ],
        timeout=180,
    )
    (video_dir / "subtitle_download.log").write_text(result.stdout + "\n" + result.stderr, encoding="utf-8")
    if result.returncode != 0:
        return None

    vtt_files = sorted(video_dir.glob("*.vtt"), key=lambda p: (len(p.name), p.name))
    return vtt_files[0] if vtt_files else None


def video_id_from_url(url: str) -> str:
    match = re.search(r"[?&]v=([a-zA-Z0-9_-]+)", url)
    if match:
        return match.group(1)
    return safe_slug(url, 20)


def parse_vtt(path: Path) -> List[Dict[str, object]]:
    cues: List[Dict[str, object]] = []
    current_time: Optional[Tuple[float, float]] = None
    current_text: List[str] = []

    def flush() -> None:
        nonlocal current_time, current_text
        if current_time and current_text:
            text = clean_caption_text(" ".join(current_text))
            if text:
                cues.append({"start": current_time[0], "end": current_time[1], "text": text})
        current_time = None
        current_text = []

    for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line:
            flush()
            continue
        if line.startswith(("WEBVTT", "Kind:", "Language:", "NOTE", "STYLE")):
            continue
        if "-->" in line:
            flush()
            left, right = line.split("-->", 1)
            current_time = (parse_timestamp(left.strip()), parse_timestamp(right.strip().split()[0]))
            continue
        if current_time:
            current_text.append(line)
    flush()

    return merge_repeated_cues(cues)


def fetch_transcript_cues(video_id: str, video_dir: Path) -> List[Dict[str, object]]:
    if YouTubeTranscriptApi is None:
        return []
    try:
        transcript = YouTubeTranscriptApi().fetch(video_id, languages=("en", "en-US", "en-GB"))
    except Exception as exc:
        (video_dir / "transcript_api_error.log").write_text(str(exc), encoding="utf-8")
        return []

    raw_items = []
    cues = []
    for item in transcript:
        if hasattr(item, "start"):
            data = {"start": item.start, "duration": item.duration, "text": item.text}
        else:
            data = dict(item)
        raw_items.append(data)
        start = float(data.get("start", 0.0))
        duration = float(data.get("duration", 0.0))
        text = clean_caption_text(str(data.get("text", "")))
        if text:
            cues.append({"start": start, "end": start + duration, "text": text})

    (video_dir / "transcript_api.json").write_text(json.dumps(raw_items, ensure_ascii=False, indent=2), encoding="utf-8")
    return merge_repeated_cues(cues)


def load_transcript_api_cues(path: Path) -> List[Dict[str, object]]:
    if not path.exists():
        return []
    try:
        raw_items = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    cues = []
    for data in raw_items:
        start = float(data.get("start", 0.0))
        duration = float(data.get("duration", 0.0))
        text = clean_caption_text(str(data.get("text", "")))
        if text:
            cues.append({"start": start, "end": start + duration, "text": text})
    return merge_repeated_cues(cues)


def parse_timestamp(value: str) -> float:
    value = value.replace(",", ".")
    parts = value.split(":")
    if len(parts) == 3:
        hours, minutes, seconds = parts
    elif len(parts) == 2:
        hours, minutes, seconds = "0", parts[0], parts[1]
    else:
        return float(value)
    return int(hours) * 3600 + int(minutes) * 60 + float(seconds)


def clean_caption_text(value: str) -> str:
    value = re.sub(r"<[^>]+>", "", value)
    value = html.unescape(value)
    value = value.replace("\u00a0", " ")
    value = re.sub(r"\s+", " ", value).strip()
    return value


def merge_repeated_cues(cues: List[Dict[str, object]]) -> List[Dict[str, object]]:
    merged: List[Dict[str, object]] = []
    last_text = ""
    for cue in cues:
        text = str(cue["text"])
        if text == last_text:
            continue
        merged.append(cue)
        last_text = text
    return merged


def choose_clips(cues: List[Dict[str, object]], clips_per_video: int, min_len: int, max_len: int) -> List[Dict[str, object]]:
    windows: List[Dict[str, object]] = []
    if not cues:
        return windows

    for idx, cue in enumerate(cues):
        start = float(cue["start"])
        target_end = start + max_len
        window_cues = [c for c in cues[idx:] if float(c["start"]) < target_end]
        if not window_cues:
            continue
        end = float(window_cues[-1]["end"])
        duration = end - start
        if duration < min_len:
            continue
        text = " ".join(str(c["text"]) for c in window_cues)
        score = score_text(text)
        if score <= 0:
            continue
        windows.append(
            {
                "start": start,
                "end": min(end, start + max_len),
                "duration": min(end, start + max_len) - start,
                "score": score,
                "text": text[:900],
            }
        )

    windows.sort(key=lambda item: (float(item["score"]), float(item["duration"])), reverse=True)
    selected: List[Dict[str, object]] = []
    for window in windows:
        if any(overlap_ratio(window, existing) > 0.35 for existing in selected):
            continue
        selected.append(window)
        if len(selected) >= clips_per_video:
            break
    selected.sort(key=lambda item: float(item["start"]))
    return selected


def score_text(text: str) -> int:
    lower = text.lower()
    score = 0
    for keyword in KEYWORDS:
        score += len(re.findall(rf"(?<![a-z0-9]){re.escape(keyword)}(?![a-z0-9])", lower)) * 2
    for phrase in SIGNAL_PHRASES:
        if phrase in lower:
            score += 3
    if len(text) > 500:
        score += 2
    return score


def overlap_ratio(a: Dict[str, object], b: Dict[str, object]) -> float:
    start = max(float(a["start"]), float(b["start"]))
    end = min(float(a["end"]), float(b["end"]))
    overlap = max(0.0, end - start)
    shortest = min(float(a["duration"]), float(b["duration"]))
    return overlap / shortest if shortest else 0.0


def format_ts(seconds: float) -> str:
    seconds = max(0.0, seconds)
    whole = int(seconds)
    return f"{whole // 3600:02d}:{(whole % 3600) // 60:02d}:{whole % 60:02d}"


def download_clip(candidate: Dict[str, object], clip: Dict[str, object], video_dir: Path, index: int, ffmpeg_path: str) -> Optional[Path]:
    video_id = video_id_from_url(str(candidate["url"]))
    start = format_ts(float(clip["start"]))
    end = format_ts(float(clip["end"]))
    out_tpl = str(video_dir / f"{video_id}_clip{index:02d}_{start.replace(':', '')}-{end.replace(':', '')}.%(ext)s")

    result = run_yt_dlp(
        [
            "--no-playlist",
            "--download-sections",
            f"*{start}-{end}",
            "--force-keyframes-at-cuts",
            "--ffmpeg-location",
            ffmpeg_path,
            "-f",
            "bv*[height<=1080]+ba/b[height<=1080]/b",
            "-o",
            out_tpl,
            str(candidate["url"]),
        ],
        timeout=600,
    )
    (video_dir / f"clip{index:02d}_download.log").write_text(result.stdout + "\n" + result.stderr, encoding="utf-8")
    if result.returncode != 0:
        return download_clip_via_full_file(candidate, clip, video_dir, index, ffmpeg_path)
    matches = sorted(video_dir.glob(f"{video_id}_clip{index:02d}_*.*"))
    return matches[0] if matches else None


def download_clip_via_full_file(candidate: Dict[str, object], clip: Dict[str, object], video_dir: Path, index: int, ffmpeg_path: str) -> Optional[Path]:
    video_id = video_id_from_url(str(candidate["url"]))
    source = download_full_video(candidate, video_dir)
    if not source:
        return None

    start = format_ts(float(clip["start"]))
    end = format_ts(float(clip["end"]))
    output = video_dir / f"{video_id}_clip{index:02d}_{start.replace(':', '')}-{end.replace(':', '')}.mp4"
    cmd = [
        ffmpeg_path,
        "-y",
        "-ss",
        start,
        "-to",
        end,
        "-i",
        str(source),
        "-c",
        "copy",
        str(output),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    (video_dir / f"clip{index:02d}_local_cut.log").write_text(result.stdout + "\n" + result.stderr, encoding="utf-8")
    if result.returncode == 0 and output.exists() and output.stat().st_size > 0:
        return output

    # Copy mode can fail on keyframe boundaries; re-encode as a reliable fallback.
    cmd = [
        ffmpeg_path,
        "-y",
        "-ss",
        start,
        "-to",
        end,
        "-i",
        str(source),
        "-vf",
        "scale='min(1280,iw)':-2",
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "23",
        "-c:a",
        "aac",
        "-b:a",
        "128k",
        str(output),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    (video_dir / f"clip{index:02d}_local_reencode.log").write_text(result.stdout + "\n" + result.stderr, encoding="utf-8")
    if result.returncode == 0 and output.exists() and output.stat().st_size > 0:
        return output
    return None


def download_full_video(candidate: Dict[str, object], video_dir: Path) -> Optional[Path]:
    video_id = video_id_from_url(str(candidate["url"]))
    existing = sorted(video_dir.glob(f"{video_id}_source.*"))
    if existing:
        return existing[0]

    out_tpl = str(video_dir / f"{video_id}_source.%(ext)s")
    result = run_yt_dlp(
        [
            "--no-playlist",
            "-f",
            "18/b[ext=mp4][height<=720]/b[height<=720]/best",
            "-o",
            out_tpl,
            str(candidate["url"]),
        ],
        timeout=1200,
    )
    (video_dir / "source_download.log").write_text(result.stdout + "\n" + result.stderr, encoding="utf-8")
    if result.returncode != 0:
        return None
    matches = sorted(video_dir.glob(f"{video_id}_source.*"))
    return matches[0] if matches else None


def write_clip_plan(candidate: Dict[str, object], cues: List[Dict[str, object]], clips: List[Dict[str, object]], video_dir: Path, files: List[Optional[Path]]) -> None:
    transcript_path = video_dir / "transcript.txt"
    transcript_path.write_text(
        "\n".join(f"[{format_ts(float(c['start']))}] {c['text']}" for c in cues),
        encoding="utf-8",
    )

    lines = [
        f"# {candidate['title']}",
        "",
        f"- Channel: {candidate['channel']}",
        f"- URL: {candidate['url']}",
        f"- Published: {candidate.get('published', '')}",
        "",
        "## Rough Clip Drafts",
        "",
    ]
    plan = []
    for idx, clip in enumerate(clips, start=1):
        file_path = files[idx - 1] if idx - 1 < len(files) else None
        lines.extend(
            [
                f"### Clip {idx}",
                "",
                f"- Time: {format_ts(float(clip['start']))} - {format_ts(float(clip['end']))}",
                f"- Duration: {float(clip['duration']):.1f}s",
                f"- Score: {clip['score']}",
                f"- File: {file_path if file_path else 'download failed or skipped'}",
                "",
                "Transcript preview:",
                "",
                f"> {clip['text']}",
                "",
            ]
        )
        plan.append(
            {
                "index": idx,
                "start": clip["start"],
                "end": clip["end"],
                "duration": clip["duration"],
                "score": clip["score"],
                "text_preview": clip["text"],
                "file": str(file_path) if file_path else None,
            }
        )

    (video_dir / "clip_plan.md").write_text("\n".join(lines), encoding="utf-8")
    (video_dir / "clip_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Download captions and rough clip drafts for candidate videos.")
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--limit", type=int, default=4)
    parser.add_argument("--start-index", type=int, default=0, help="Zero-based candidate offset")
    parser.add_argument("--clips-per-video", type=int, default=1)
    parser.add_argument("--min-len", type=int, default=45)
    parser.add_argument("--max-len", type=int, default=90)
    parser.add_argument("--captions-only", action="store_true", help="Only download captions and write clip plans")
    args = parser.parse_args()

    ffmpeg_path = get_ffmpeg_path()
    if not args.captions_only and not ffmpeg_path:
        print("[error] ffmpeg not found. Install ffmpeg or rerun with --captions-only.", file=sys.stderr)
        return 2

    all_candidates = load_candidates(args.input, 0)
    candidates = all_candidates[args.start_index :]
    if args.limit:
        candidates = candidates[: args.limit]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    summary = []

    for candidate in candidates:
        video_id = video_id_from_url(str(candidate["url"]))
        video_dir = args.output_dir / f"{video_id}_{safe_slug(str(candidate['title']))}"
        print(f"[info] Processing {candidate['channel']}: {candidate['title']}", flush=True)
        cached_api = video_dir / "transcript_api.json"
        cues = load_transcript_api_cues(cached_api)
        subtitle_path = None
        if cues:
            print(f"[info] Using cached transcript for {video_id}", flush=True)
        else:
            subtitle_path = download_subtitles(candidate, video_dir)
        if subtitle_path and not cues:
            cues = parse_vtt(subtitle_path)
        elif not cues:
            print(f"[warn] No subtitle file downloaded for {video_id}; trying transcript API", file=sys.stderr)
            cues = fetch_transcript_cues(video_id, video_dir)

        if not cues:
            print(f"[warn] No transcript available for {video_id}", file=sys.stderr)
            summary.append({"video_id": video_id, "title": candidate["title"], "status": "no_subtitles"})
            continue

        clips = choose_clips(cues, args.clips_per_video, args.min_len, args.max_len)
        files: List[Optional[Path]] = []
        for index, clip in enumerate(clips, start=1):
            if args.captions_only:
                files.append(None)
            else:
                assert ffmpeg_path is not None
                files.append(download_clip(candidate, clip, video_dir, index, ffmpeg_path))
        write_clip_plan(candidate, cues, clips, video_dir, files)
        summary.append(
            {
                "video_id": video_id,
                "title": candidate["title"],
                "status": "ok",
                "subtitle": str(subtitle_path) if subtitle_path else None,
                "clip_plan": str(video_dir / "clip_plan.md"),
                "files": [str(f) if f else None for f in files],
            }
        )

    summary_path = args.output_dir / "summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[done] Wrote {summary_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
