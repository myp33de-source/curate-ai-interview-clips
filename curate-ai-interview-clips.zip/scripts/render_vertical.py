#!/usr/bin/env python3
"""Render 16:9 clips into a 9:16 template with white safe zones."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List


ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / "vendor"
if VENDOR.exists():
    sys.path.insert(0, str(VENDOR))

try:
    import imageio_ffmpeg
except ImportError:  # pragma: no cover
    imageio_ffmpeg = None


DEFAULT_METADATA = ROOT / "vertical_metadata.json"
DEFAULT_OUTPUT_DIR = ROOT / "vertical_outputs"

# Keep all editorial content inside the centered 6:7 region (y=330..1590).
CONTENT_TOP = 330
CONTENT_BOTTOM = 1590
TITLE_Y = 410
VIDEO_Y = 520
SUBTITLE_Y = 1255
META_Y = 1530


def get_ffmpeg_path() -> str:
    if imageio_ffmpeg is not None:
        try:
            return imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            pass
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not found")
    return ffmpeg


def ass_time(seconds: float) -> str:
    cs = int(round(seconds * 100))
    h = cs // 360000
    cs %= 360000
    m = cs // 6000
    cs %= 6000
    s = cs // 100
    cs %= 100
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def wrap_cn(text: str, width: int) -> str:
    lines: List[str] = []
    current = ""
    for char in text:
        current += char
        if len(current) >= width and char in "，。；：、？！ ":
            lines.append(current.strip())
            current = ""
        elif len(current) >= width + 4:
            lines.append(current.strip())
            current = ""
    if current.strip():
        lines.append(current.strip())
    return r"\N".join(lines)


def escape_ass(text: str) -> str:
    return text.replace("{", "").replace("}", "").replace("\n", r"\N")


def write_ass(item: Dict[str, object], path: Path) -> None:
    title = wrap_cn(str(item["title"]), 15)
    meta = wrap_cn(str(item["meta"]), 24)
    subs = item.get("subtitles", [])
    duration = max(float(s["end"]) for s in subs) if subs else 90.0

    lines = [
        "[Script Info]",
        "ScriptType: v4.00+",
        "PlayResX: 1080",
        "PlayResY: 1920",
        "WrapStyle: 2",
        "ScaledBorderAndShadow: yes",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        "Style: Title,Hiragino Sans GB,58,&H00111111,&H000000FF,&H00FFFFFF,&H00000000,1,0,0,0,100,100,0,0,1,0,0,8,70,70,70,1",
        "Style: Meta,Hiragino Sans GB,32,&H00444444,&H000000FF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,0,0,8,70,70,70,1",
        "Style: Sub,Hiragino Sans GB,44,&H00111111,&H000000FF,&H00FFFFFF,&H00000000,1,0,0,0,100,100,0,0,1,0,0,8,95,95,70,1",
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
        f"Dialogue: 2,{ass_time(0)},{ass_time(duration)},Title,,0,0,0,,{{\\pos(540,{TITLE_Y})}}{escape_ass(title)}",
        f"Dialogue: 2,{ass_time(0)},{ass_time(duration)},Meta,,0,0,0,,{{\\pos(540,{META_Y})}}{escape_ass(meta)}",
    ]

    for sub in subs:
        text = wrap_cn(str(sub["text"]), 18)
        lines.append(
            f"Dialogue: 3,{ass_time(float(sub['start']))},{ass_time(float(sub['end']))},Sub,,0,0,0,,{{\\pos(540,{SUBTITLE_Y})}}{escape_ass(text)}"
        )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def render_item(item: Dict[str, object], output_dir: Path, ffmpeg: str, metadata_dir: Path) -> Path:
    input_path = Path(str(item["input"]))
    if not input_path.is_absolute():
        input_path = metadata_dir / input_path
    output_dir.mkdir(parents=True, exist_ok=True)
    ass_path = output_dir / f"{item['video_id']}.ass"
    output_path = output_dir / str(item["output_name"])
    write_ass(item, ass_path)
    subs = item.get("subtitles", [])
    duration = max(float(s["end"]) for s in subs) if subs else None

    # A 1080x1260 center region is exactly 6:7, leaving 330 px white above/below.
    filter_complex = (
        "color=c=white:s=1080x1920[bg];"
        "[0:v]scale=1000:562:force_original_aspect_ratio=decrease,"
        "pad=1000:562:(ow-iw)/2:(oh-ih)/2:color=white[vid];"
        f"[bg][vid]overlay=40:{VIDEO_Y}:shortest=1[tmp];"
        f"[tmp]subtitles='{escape_filter_path(ass_path)}'[outv]"
    )
    cmd = [
        ffmpeg,
        "-y",
        "-loglevel",
        "warning",
        "-i",
        str(input_path),
        "-filter_complex",
        filter_complex,
        "-map",
        "[outv]",
        "-map",
        "0:a?",
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "22",
        "-c:a",
        "aac",
        "-b:a",
        "128k",
    ]
    if duration:
        cmd.extend(["-t", f"{duration:.2f}"])
    cmd.extend([
        "-movflags",
        "+faststart",
        str(output_path),
    ])
    log_path = output_dir / f"{item['video_id']}_render.log"
    with log_path.open("w", encoding="utf-8") as log:
        result = subprocess.run(cmd, stdout=log, stderr=log, text=True, timeout=600)
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg failed for {item['video_id']}; see render log")
    return output_path


def escape_filter_path(path: Path) -> str:
    return str(path).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")


def main() -> int:
    parser = argparse.ArgumentParser(description="Render vertical 9:16 white-template clips.")
    parser.add_argument("--metadata", type=Path, default=DEFAULT_METADATA)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()

    ffmpeg = get_ffmpeg_path()
    items = json.loads(args.metadata.read_text(encoding="utf-8"))
    if args.limit:
        items = items[: args.limit]

    outputs = []
    for item in items:
        print(f"[info] Rendering {item['video_id']}: {item['title']}", flush=True)
        outputs.append(str(render_item(item, args.output_dir, ffmpeg, args.metadata.resolve().parent)))

    summary = args.output_dir / "vertical_summary.json"
    summary.write_text(json.dumps(outputs, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[done] Wrote {summary}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
