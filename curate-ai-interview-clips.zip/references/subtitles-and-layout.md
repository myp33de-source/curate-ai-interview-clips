# Subtitles And Layout

## Translation

- Translate only contemporaneous speech from the selected excerpt.
- Preserve sentence order, intent, uncertainty, modality, and named entities.
- Keep each Chinese cue aligned to the English cue carrying that meaning.
- Use natural spoken Chinese without summarizing or editorializing.
- Do not add “他说”, “她表示”, “主持人问”, speaker names, commentary, or connective narration unless those words are spoken.
- Do not turn possibilities into facts or weaken/strengthen the speaker's certainty.
- Retain meaningful numbers, comparisons, product names, and technical terms.
- Review the full excerpt once after translation to catch pronoun and context errors.

## Timing

- Prefer one or two short Chinese lines per cue.
- Keep a cue on screen long enough to read; combine adjacent micro-cues when they form one sentence.
- Do not place one English sentence's translation under a different spoken sentence.
- Start at the first complete setup sentence and end after the conclusion lands.

## Canvas

- Output: 1080x1920, 9:16.
- Pure-white safe zones: y=0..329 and y=1590..1919.
- Editorial region: 1080x1260, y=330..1589, ratio 6:7.
- Order inside the editorial region: title, 16:9 source video, Chinese subtitles, guest/source metadata.
- Keep the source image proportional; do not crop faces or stretch 16:9 footage.
- Keep subtitles and metadata within the editorial region and visually separated.

## Quality check

Inspect the first frame, a middle subtitle-heavy frame, and the final frame. Confirm that text fits, the white zones remain clean, the clip has audio, and the last sentence is complete.
