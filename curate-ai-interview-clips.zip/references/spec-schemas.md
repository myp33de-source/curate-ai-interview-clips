# Spec Schemas

## Approved candidates

`download_and_clip.py` expects a wrapper object:

```json
{
  "candidates": [
    {
      "channel": "Y Combinator",
      "title": "Original video title",
      "url": "https://www.youtube.com/watch?v=VIDEO_ID",
      "published": "2026-09-18T00:00:00Z"
    }
  ]
}
```

## Refined clip specs

```json
[
  {
    "video_id": "VIDEO_ID",
    "channel": "Y Combinator",
    "title": "Original video title",
    "url": "https://www.youtube.com/watch?v=VIDEO_ID",
    "start": 1780.0,
    "end": 1888.0
  }
]
```

## Vertical metadata

Paths are relative to the metadata file unless absolute.

```json
[
  {
    "video_id": "VIDEO_ID",
    "input": "refined_clips/VIDEO_ID/example.mp4",
    "output_name": "01_topic_vertical.mp4",
    "title": "AI让一人公司从少数变成主流",
    "meta": "Garry Tan等 YC 合伙人｜来源：Y Combinator",
    "subtitles": [
      {"start": 0.0, "end": 3.2, "text": "现在，接近五分之一的公司只有一位创始人。"},
      {"start": 3.2, "end": 7.1, "text": "AI工具让一个人也能管理完整的开发流程。"}
    ]
  }
]
```

Subtitle times are relative to the start of the refined clip, not the full source video.
