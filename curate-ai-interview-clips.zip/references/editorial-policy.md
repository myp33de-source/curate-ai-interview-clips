# Editorial Policy

## Selection threshold

Select a topic only when it has at least one strong distribution entry point. Prefer topics satisfying two or more:

1. A hot product or company: Codex, ChatGPT, Claude, Gemini, OpenAI, Anthropic, Google DeepMind, NVIDIA, or another currently high-attention name.
2. A recognized founder, researcher, executive, investor, or operator.
3. A claim that is contrarian, surprising, consequential, or directly relevant to a broad working audience.

Downgrade unknown companies paired with narrow enterprise software, niche business models, unfamiliar guests, or topics requiring extensive background.

## Ranking order

Rank candidates by:

1. Current public attention around the named product, company, or person.
2. Strength and specificity of the judgment.
3. Broad relevance to work, careers, products, organizations, or AI adoption.
4. Presence of a clean 60-120 second passage that contains setup, reasoning, and conclusion.
5. Credibility and traceability of the source.

Information density alone is not enough. A highly technical but socially narrow passage should lose to a clear, consequential judgment with a recognizable hook.

## Reject

- sponsor reads, promotional calls to action, and affiliate mentions
- show openings, guest biographies, and housekeeping
- duplicated viewpoints already proposed or processed
- vague optimism or fear without evidence or mechanism
- clips that require missing context to avoid distortion
- excerpts ending mid-sentence or before the conclusion
- claims whose speaker or source cannot be verified

## Candidate-list format

For each candidate provide:

```text
候选标题：
入选理由：
嘉宾与核心判断：
原视频链接：
推荐切片角度：
风险或待验证项：
```

Return at most three. State why fewer were selected when the pool is weak.

## Approval gate

The topic list is a decision artifact, not permission to produce. Wait for an explicit selection such as “做第1和第3条” before downloading video or creating a clip.
